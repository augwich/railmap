# Piwik GeoIP2 Plugin

## Description

This plugin adds support for [MaxMind GeoIP2](https://www.maxmind.com/en/geoip2-services-and-databases) database.

Currently supported databases:

* GeoIP2-City.mmdb
* GeoLite2-City.mmdb
* GeoIP2-Country.mmdb
* GeoLite2-Country.mmdb

## [How do i get GeoIP2 databases](https://github.com/diabl0/piwik-geoip2/wiki/How-do-I-get-the-GeoIP-2-databases%3F)

## [FAQ](https://github.com/diabl0/piwik-geoip2/wiki/FAQ)
