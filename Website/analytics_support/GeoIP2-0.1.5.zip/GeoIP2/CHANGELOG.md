## Changelog

#1.3

+ code cleanup
